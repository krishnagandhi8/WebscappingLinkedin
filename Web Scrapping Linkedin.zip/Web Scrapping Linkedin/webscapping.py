import pandas as pd
from bs4 import BeautifulSoup
import selenium
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver import ChromeOptions
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import WebDriverException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def webscrapping():
    driver = webdriver.Chrome(r'D:\Chrome\80\chromedriver')
    driver.maximize_window()
    driver.get("https://www.linkedin.com/feed/")


    button = driver.find_element_by_xpath('/html/body/div/main/p/a')
    button.click()

    time.sleep(2)
    driver.find_element_by_xpath('//*[@id="username"]').send_keys("USERNAME"+Keys.TAB+"PASSWORD"+Keys.ENTER)

    driver.implicitly_wait(1)
    search_item = driver.find_element_by_xpath('//*[@id="ember42"]/input')
    search_item.send_keys("yash gandhi")
    driver.implicitly_wait(2)
    time.sleep(3)
    search_item.send_keys(Keys.DOWN)
    time.sleep(2)
    search_item.send_keys(Keys.RETURN)
    driver.implicitly_wait(10)

    # time.sleep(2)
    # iframe = driver.find_element_by_xpath('/html/body/iframe')
    # driver.switch_to.frame(iframe)
    heading = driver.find_element_by_xpath('/html/body/div[6]/div[3]/div[3]/div/div/div/div/div[2]/main/div[1]/section/div[2]')
    soup = BeautifulSoup(heading.get_attribute('innerHTML'),'html.parser')
    try:
        name = soup.find('li', class_='inline t-24 t-black t-normal break-words').text.lstrip().rstrip()
    except:
        name = None
    try:
        badge = soup.find('span', class_='dist-value').text.lstrip().rstrip()
    except:
        badge = None
    try:
        info = soup.find('h2', class_='mt1 t-18 t-black t-normal').text.lstrip().rstrip()
    except:
        info = None
    try:
        location = soup.find('li', class_='t-16 t-black t-normal inline-block').text.lstrip().rstrip()
    except:
        location = None
    try:
        institution = soup.find('span', class_='text-align-left ml2 t-14 t-black t-bold full-width lt-line-clamp lt-line-clamp--multi-line ember-view').text
    except:
        institution = None
    # try:
    image = str(soup.find('div', class_='presence-entity pv-top-card__image presence-entity--size-9 ember-view')).split('"')[13]
    # except:
    #     image = None
    print(f'Name: {name}')
    print(f'Badge: {badge}')
    print(f'Info: {info}')
    print(f'Location: {location}')
    print(f'Institution: {institution}')
    print(f'Image: {image}')
    driver.close()

webscrapping()    