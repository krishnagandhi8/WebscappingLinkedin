# linkedin-profile-scraper

This is a complete profile scraper that returns a JSON file.
